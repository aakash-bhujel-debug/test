a=0
b=1
while b<50:
    print(b)
    a = b
    b=a+b