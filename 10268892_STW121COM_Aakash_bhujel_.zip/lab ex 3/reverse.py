def reverse(a):
    str=""
    for i in a:
        str=i+str
    print(str)
a=input("enter a word")
reverse(a)
