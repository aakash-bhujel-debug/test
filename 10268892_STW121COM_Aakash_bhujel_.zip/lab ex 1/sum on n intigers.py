n=int(input("enter the value of n"))
x=(n*(n+1))/2
print(x)