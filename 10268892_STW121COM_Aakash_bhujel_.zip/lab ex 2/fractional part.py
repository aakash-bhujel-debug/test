a=float(input("enter any number"))
b=a - int(a)
print(b)