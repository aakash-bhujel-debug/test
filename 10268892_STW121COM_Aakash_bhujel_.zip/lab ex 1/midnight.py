a=int(input("enter time"))
x=a//60
b=x
y=a%60
print("the time from midnight is",x,":",y)