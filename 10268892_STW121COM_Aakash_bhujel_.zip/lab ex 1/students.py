a=int(input("enter the number of students in first class"))
b=int(input("enter the number of students in second class"))
c=int(input("enter the number of students in third class"))
x=(a//2)
m=(a%2)
if (m==1):
    print("the total number of benches required is",(x+1))
else:
    print("the total number of benches required is",x)
y=(b//2)
n=(b%2)
if (n==1):
    print("the total number of benches required is",(y+1))
else:
    print("the total nmmber of benches required is",y)
z=(c//2)
o=(c%2)
if (o==1):
    print("the total number of benches required is",(z+1))
else:
    print("the total number os benches required is",z)