# Labexercise 6



# 1. Write a Python program to find out the sum of element of a list by using recursion





 def fun(a,b):

     if b==1:

         return 1

     else:

         return a[b-1]+fun(a,b-1)

 n=int(input('enter a number of element for list:'))

 c=[]

 for i in range(0,n):

     c.append(i)

 d=fun(c,n)

 print(d)



# 2. Write a Python program to display the multiplication of 3  upto n number using recursion.



 a=3

 def num(b):

     if b==1:

         return 1

     else:

         for i in range(1,b+1,1):



             a=a*i

             print(a)

         return num(b-1)



 b=int(input('enter a value:'))

 print(num(b))



#3 Write a recursive Python function that returns the sum

# of first n integers



sum=0

 def fun(a):

     if a==1:

         return 1

     else:

         return sum+fun(a-1)



 a=int(input('enter a number:'))

 print(fun(a))



# 4 and 5. Write a recursive function that

# check if the given string is palindrome, else not palindrome.



 def fun(s):

     # rev = (s[::-1])

     if len(s)<1:

         return True

     else:

         # if rev==s:

         if s[0]==s[-1]:

             return fun(s[1:-1])

         else:

             return False

 a=str(input('enter a string::'))

 if (fun(a)==True):

     print(' strin is pallindrom')

 else:

     print('string is not pallindrome')

