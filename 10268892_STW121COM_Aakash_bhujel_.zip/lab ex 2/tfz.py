x=int(input("enter any number"))
if x>0:
    print("true")
elif(x<0):
    print("false")
else:
    print("zero")