r=float(input("enter the radius"))
pi=3.14
area= pi*(r**2)
print("the area of triangl is",area)

