l=int(input("enter length"))
b=int(input("enter breadth"))
h=int(input("enter height"))
x=l*b*h
print("the area of triangle is",x)