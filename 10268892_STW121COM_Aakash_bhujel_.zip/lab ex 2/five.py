list = [1,2,3,4,5]
if 5 in list:
    print("yes")
else:
    print("no")
