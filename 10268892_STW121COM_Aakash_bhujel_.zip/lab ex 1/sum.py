x=int(input("enter first number"))
y=int(input("enter second number"))
z=int(input("enter third number"))
r=x+y+z
print("the sum of",x,",",y,"and ",z,"is",r)