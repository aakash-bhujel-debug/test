a=int(input("enter the body mass of the person"))
b=int(input("enter the height of the person"))
bmi=(a/(b**2))
print("BMI=",bmi)