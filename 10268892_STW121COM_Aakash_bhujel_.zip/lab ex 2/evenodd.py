x=int(input("enter any number"))
y=x%2
if y==0:
    print("even")
else:
    print("odd")