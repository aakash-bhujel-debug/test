a=int(input("enter any number"))
x=a%10
print("the last digit of",a,"is",x)