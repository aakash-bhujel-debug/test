for i in range(1500,2701):
    a=i%7
    b=i%5
    if a==0 and b==0:
        print (i)
    