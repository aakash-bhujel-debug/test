for x in range(6):
    if (x == 3 or x==6):
        continue
print()